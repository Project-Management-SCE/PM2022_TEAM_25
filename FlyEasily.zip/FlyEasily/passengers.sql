SELECT * FROM passengers.passengers;

SELECT * FROM passengers.orders;